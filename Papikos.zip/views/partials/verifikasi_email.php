<div class="">
    <h1>Papikos</h1>
</div>
<div>
    <h1>Halo Mochamad Ludfi Rahman</h1>
    <p>silahkan masukkan kode di bawah ini untuk verifikasi ulang akunmu</p>
    <h1>HSJHSJSH</h1>
</div>