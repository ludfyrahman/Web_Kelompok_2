<footer class="footer">
    <div class="row">
    <div class="col-sm-6 text-center text-sm-right order-sm-1">
        <ul class="text-gray">
        <li><a href="#">Terms of use</a></li>
        <li><a href="#">Privacy Policy</a></li>
        </ul>
    </div>
    <div class="col-sm-6 text-center text-sm-left mt-3 mt-sm-0">
        <small class="text-muted d-block">Copyright © 2019 <a href="http://www.uxcandy.co" target="_blank">UXCANDY</a>. All rights reserved</small>
        <small class="text-gray mt-2">Handcrafted With <i class="mdi mdi-heart text-danger"></i></small>
    </div>
    </div>
</footer>