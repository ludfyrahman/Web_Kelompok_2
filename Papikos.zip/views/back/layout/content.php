<div class="page-body">
        <?php 
        include BASEPATH . "views/back/layout/sidebar.php";
        ?>
    <div class="page-content-wrapper">
        <?php include BASEPATH . "views/back/content/$content.php";?>
        <?php include BASEPATH . "views/back/layout/footer.php";?>
        
    </div>
</div>