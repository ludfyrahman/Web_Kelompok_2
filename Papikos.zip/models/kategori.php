<?php

class Kategori extends ORM{
    
}